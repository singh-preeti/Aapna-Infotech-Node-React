document.getElementById("b1").addEventListener("click",sample);
function sample()
     {
var a=document.getElementById("t1").value;
var b=document.getElementById("t2").value;
var c=parseInt(a)
var d=parseInt(b)
var e=c+d;

document.getElementById("p1").innerHTML="sum is "+e;
     }
    