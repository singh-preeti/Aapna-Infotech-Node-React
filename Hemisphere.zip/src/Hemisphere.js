import React from "react";
import northPic from './Image/north.jpg';
import southPic from './Image/south.jpg';

const Hemisphere = ({latitude}) => {
    
    const hemisphere = latitude >0 ? 'Northern hemisphere': 'Southern hemisphere';
    const picture = latitude>0 ? northPic : southPic;
        return(
        <div>
            <img src={picture} alt="" />
            {hemisphere}</div>
    )
}
export default Hemisphere