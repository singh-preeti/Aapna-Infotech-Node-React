import React,{Component} from 'react'

class ConditionDemo extends Component
{
    constructor(props)
    {
        super(props)
        this.state ={
            userLoggedIn: true
        }
    }
    // if else approach
   // render(){
       // if(this.state.userLoggedIn)
       /* {
            return <div>Welcome Kunal</div>
        }
        else{
            return <div>Welcome Guest</div>
        }
    }*/
    //element-variables approach
    /*render(){
        let message
         if(this.state.userLoggedIn)
         {
             message = <div><h1>Welcome Kunal</h1></div>
         }
         else{
             message=  <div><h1>Welcome Guest</h1></div>
         }
         return <div>{message}</div>
     }*/
     render()
     {
         return this.state.userLoggedIn  && <div>Welcome Preety</div>
     }
}
export default ConditionDemo