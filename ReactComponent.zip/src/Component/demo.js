import React, {Component} from 'react';

class demo extends Component {
 
render() {
return (
<div>
<p>Condition to apply coupon:</p>
<ol>
<li>If you are ordering for the first time.</li>
<li>Minimum order amount should be greater than 1000.</li>
</ol>
</div>
);
}
}
export default demo;
