import React from 'react'

const Greeting = (props) => 
{
    console.log(props)
   
return(
<div><h1> Good Morning { props.name} likes  {props.movie}</h1>
{props.children}
</div>)
}
export default Greeting