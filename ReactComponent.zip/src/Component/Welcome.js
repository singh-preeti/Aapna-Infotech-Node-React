import React,{ Component} from 'react'

class Welcome extends Component
{
    render()
    {
        return <h1>Welcome to JFS training camp {this.props.name}Likes {this.props.movie}</h1>
    }
}
export default Welcome