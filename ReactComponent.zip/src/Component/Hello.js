import React from 'react'

//function Hello()
//{
   // return <p>Hello guys hope you are doing well</p>
//}
 const Hello = () => <h1>Hello</h1>
export default Hello