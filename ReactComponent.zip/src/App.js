import logo from './logo.svg';
import './App.css';
import Greeting from './Component/Greeting';
import Hello from './Component/Hello';
import Counter from './Component/Counter';
import ConditionDemo from './Component/ConditionDemo';
import ClassClick from './Component/ClassClick';
import Message from './Component/Message';
import FunctionClick from './Component/FunctionClick';
import Form from './Component/Form';
import PostList from './Component/PostList';
import EventBind from './Component/EventBind';
import PostForm from './Component/PostForm';
function App() {
  return (
    <div className="App">
   <PostForm />
     
    </div>
  );
}

export default App;
