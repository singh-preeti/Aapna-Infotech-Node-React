function add(a,b)
{
    return a+b
}
console.log(a+b);
console.log("Saved")