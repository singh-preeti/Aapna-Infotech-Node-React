var calc = require('./calc.js')
result = calc.sub(10,5)

console.log("the result is " + result);