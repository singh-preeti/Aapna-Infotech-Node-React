var a= 7
var b= 2

var c= a+b

console.log("the output is" +c);