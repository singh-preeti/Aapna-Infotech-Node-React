var fs = require('fs')

fs.readFile('calc.js',function(err){
    console.log("Reading...");
})

//writeFile
//appenfFile
//unlink
//ReadFile