var calc = require('./calc.js')
result = calc.add(2,5)

console.log("the result is " + result);