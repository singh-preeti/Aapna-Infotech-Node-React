function add(a,b){
    return a+b;
}
result = add(2,5)

console.log("the result is " + result);