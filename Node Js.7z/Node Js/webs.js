const express = require('express');

const webs = express();

//webs.get('/emp', function(req,res){
   // res.send('hello world!')
//})
webs.get('/emp/:id', function(req,res){
    const id = req.params.id
    res.send('hey Himanshu' +id)
})

webs.listen(9001, function(req,res){
    console.log('Running...' )
})