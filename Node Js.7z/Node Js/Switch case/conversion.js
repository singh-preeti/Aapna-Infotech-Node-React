let num = "10"
// Explicit Conversion
//let num = Number("10")

// undefined data
// let num


console.log(num, typeof num);