let laptop1 = 
{
    cpu : 'i5',
    ram :16,
    brand: 'HP',
    getconfiguration: function(){
        console.log(this.cpu);
    }
}
let laptop2 = 
{
    cpu : 'i9',
    ram :16,
    brand: 'Dell',
    getconfiguration: function(){
        console.log(this.cpu);
    }
}

laptop2.getconfiguration();