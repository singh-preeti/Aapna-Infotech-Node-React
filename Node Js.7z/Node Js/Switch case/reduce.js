
const numbers = [170, 50, 25];
sum = numbers.reduce(myFunc);
console.log(sum)
function myFunc(total, num) {
  return total - num;
}
