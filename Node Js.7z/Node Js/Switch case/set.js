let nums = new Set();
nums.add(3);
nums.add(4);
nums.add(3);
nums.add("Preety");
nums.add("Sudha");
nums.add("Sudha");

console.log(nums.has("Preety"));