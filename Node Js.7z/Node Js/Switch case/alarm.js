let day = "Tuesday"

switch(day){
    case 'Monday':
        console.log("7 am");
        break;
    case 'Tuesday':
        console.log("4 am");
    case 'Wednesday':
         
    case 'Thursday':
       
        break;
    case 'Friday':
        console.log("9 am");
    case 'Saturday':
        console.log("8 am");
    case 'Sunday':
        console.log("5 am");
        
}