function greet()
{
    return "Good morning!"
}
let user = 'Himanshu'
let str = greet();
console.log(str , user);
