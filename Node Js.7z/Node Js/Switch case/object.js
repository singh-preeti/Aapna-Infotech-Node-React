// object litrals
let audience = {
    name: 'Navin',
    technology: 'Javascript'
    //with 2 words use square bracket only
   
 }
// whatever is not primitive is called object
// with . operator
//console.log(audience.technology);
// with square bracket
console.log(audience['technology']);
