let map = new Map();

map.set("Himanshu","Nodejs");
map.set("Sudha","Java");
map.set("Rahul","ReactJs");
map.set("Rahul","Js");

for(let [k,v] of map){
console.log(k, ":", v);
}