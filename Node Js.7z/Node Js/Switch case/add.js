let add = () =>{

    console.log("Hello");
    return 1;
}
//let sum = add

console.log(add());


