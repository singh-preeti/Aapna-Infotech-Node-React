let nums = [1,65,87,98,45,62,48,1];
let result = nums.filter(n =>n%2===0)
.map(s =>s *2)
.reduce((a,b)=>a+b);

console.log(result);
//console.log(nums);
// for(var i of nums)
//reducer is call back function which work with reduce array method