import React from 'react';
import ReactDOM from 'react-dom';
import profile1 from './Image/Mickey.jpeg';
import SingleComment from './SingleComment';

const App = () =>{
    return(
        <div className='ui comments'>
        <SingleComment name='Preety'
             date='Today at 5:00 Pm'
              text='Its Amazing '
              picture={profile1}>
        </SingleComment>
        <SingleComment name='Dev' 
            date='Today at 5:00 Pm' 
            text='React Post release'
            picture={profile1}>
        </SingleComment>
        <SingleComment name='Himanshu' 
            date='Today at 5:00 Pm' 
            text='React new Series'
            picture={profile1}>
        </SingleComment>
           
        </div>
        
    )
}
ReactDOM.render(
    <App />,
    document.querySelector('#root')
)