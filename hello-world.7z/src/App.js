import logo from './logo.svg';
import './App.css';

//import Greetings from'./component/Greetings.js';
import Hello  from './component/hello';
//import Demo from './component/Demo';
import Welcome  from './component/Welcome';
import Message from './component/Message';
import Clock from './component/Clock';
import App1 from './component/App1';
function App() {
  return (
    <div className="App">
    
    <App1></App1>
    </div>
  );
}

export default App;
