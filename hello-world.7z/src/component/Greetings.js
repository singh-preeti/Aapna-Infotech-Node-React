import React from 'react';

//function Greetings()
//{
  //  return <h2>Hello and Goodmorning Preety</h2>
//}
const Greetings = () => <h1>hello </h1>
export default Greetings;