import React, { Component } from 'react'

class Demo extends Component{
    render()
    {
        return <h2>Hello PPl{this.props.name}</h2>
    }
}
export default Demo